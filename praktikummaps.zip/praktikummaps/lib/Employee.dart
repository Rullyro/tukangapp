class Latilong {
  String lat;
  String long;

  Latilong({required this.lat, required this.long});

  factory Latilong.fromJson(Map<String, dynamic> json) {
    return Latilong(
      lat: json['lat'] as String,
      long: json['long'] as String,
    );
  }
}