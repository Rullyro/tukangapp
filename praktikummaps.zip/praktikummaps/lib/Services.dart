import 'dart:convert';
import 'package:http/http.dart'
as http; // add the http plugin in pubspec.yaml file.
import 'Employee.dart';

class Services {
  static const _GET_ALL_ACTION = 'GET_ALL';
  static Future<List<Latilong>> getEmployees() async {
    try {
      var map = Map<String, dynamic>();
      map['action'] = _GET_ALL_ACTION;
      var url = Uri.http("192.168.1.4", '/pemobmap/latlng.php', {'q': '{http}'});
      final response = await http.post(url, body: map);
      print('getEmployees Response: ${response.body}');
      if (200 == response.statusCode) {
        List<Latilong> list = parseResponse(response.body);
        return list;
      } else {
        return <Latilong>[];
      }
    } catch (e) {
      return <Latilong>[]; // return an empty list on exception/error
    }
  }

  static List<Latilong> parseResponse(String responseBody) {
    final parsed = json.decode(responseBody).cast<Map<String, dynamic>>();
    return parsed.map<Latilong>((json) => Latilong.fromJson(json)).toList();
  }

}